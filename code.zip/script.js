// Lists of Truths and Dares
const truths = [
    "Have you ever kept a big secret?",
    "What's the most embarrassing thing you've done?",
    "Have you ever cheated on a test?",
    "What's your biggest fear?",
    "Who do you have a crush on?",
    "If you could be invisible for a day, what's the first thing you would do?",
    "What's the biggest secret you've kept from your parents?",
    "What's the most embarrassing music you listen to?",
    "What's one thing you love most about yourself?",
    "Who is your secret crush?",
    "Who is the last person you creeped on social media?",
    "When was the last time you wet the bed?",
    "If a genie granted you three wishes, what would you ask for and why?",
    "Have you ever laughed so hard you snorted?",
"What’s the weirdest thing you’ve ever eaten?",
"Have you ever walked into a glass door?",
"If you could swap lives with a cartoon character, who would it be?",
"What’s the most embarrassing thing you’ve done in public?",
"Have you ever farted in an elevator and blamed someone else?",
"What’s your funniest nickname?",
"Have you ever worn mismatched socks or shoes in public?",
"What’s your weirdest talent?",
"Have you ever pretended to like a gift but secretly hated it?",
"Have you ever cheated on a test?",
"What’s the biggest lie you’ve ever told?",
"Have you ever read someone else’s private messages?",
"What’s something illegal you’ve done but never got caught?",
"Have you ever stalked someone on social media?",
"Have you ever had a crush on your best friend’s partner?",
"What’s something you’ve done that you regret?",
"Have you ever been caught lying?",
"If you had to delete one app from your phone, what would it be?",
"Have you ever ghosted someone?",
"If you had to switch lives with someone for a day, who would it be?",
"What’s the weirdest thing you do when you’re alone?",
"What’s the grossest thing you’ve ever eaten?",
"If you could only eat one food for the rest of your life, what would it be?",
"Have you ever eaten something off the floor?",
"What’s the strangest dream you’ve ever had?",
"Have you ever talked to yourself in the mirror?",
"What’s the dumbest way you’ve injured yourself?",
"Have you ever accidentally sent an embarrassing message?",
"What’s the most unusual thing in your room right now?",
];

const dares = [
    "Dance for 30 seconds without music!",
    "Talk in a funny accent for th e next 3 rounds.",
    "Do 10 push-ups!",
    "Sing a song loudly!",
    "Send a funny selfie to a friend.",
    "Speak in a British accent for the next 3 rounds.",
"Do your best impression of a celebrity until someone guesses who it is.",
"Talk without using the letter “S” for the next 2 minutes.",
"Sing the chorus of your favorite song out loud.",
"Try to lick your elbow (it’s almost impossible!).",
"Pretend to be a monkey for 30 seconds.",
"Walk around the room like a crab.",
"Let someone else send a message from your phone.",
"Do 10 push-ups while barking like a dog.",
"Take a silly selfie and post it on social media.",
"Let someone draw something on your face with a marker.",
"Go outside and yell “I love you, world!” as loud as you can.",
"Eat a spoonful of mustard or hot sauce.",
"Swap clothes with someone for the next round.",
"Send a heart emoji ❤️ to your last text contact.",
"Give someone a compliment in a flirtatious way.",
"Hug the person to your right for 10 seconds.",
"Whisper a secret into someone’s ear.",
"Send a flirty text to your crush (or a random person).",
"Let the group choose someone for you to send a love confession to.Show the last photo in your gallery.",
"Let someone read one message from your phone aloud.",
"Do a freestyle rap about the person sitting next to you.",
"Open your Instagram and like the first 10 posts on your feed.",
"Try to balance a spoon on your nose for 10 seconds.",
"Show your search history for the last 24 hours.",
];

// Function to pick a random truth
function getTruth() {
    const question = document.getElementById("question");
    question.textContent = truths[Math.floor(Math.random() * truths.length)];
}

// Function to pick a random dare
function getDare() {
    const question = document.getElementById("question");
    question.textContent = dares[Math.floor(Math.random() * dares.length)];
}
